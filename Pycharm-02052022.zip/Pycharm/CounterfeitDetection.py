from flask import Flask, render_template,request,redirect,session,jsonify
from DBConnection import Db
import datetime
# import demjson
app = Flask(__name__)
app.secret_key="abc"

import json
from web3 import Web3, HTTPProvider

# truffle development blockchain address
blockchain_address = 'http://127.0.0.1:8545'
# Client instance to interact with the blockchain
web3 = Web3(HTTPProvider(blockchain_address))
# Set the default account (so we don't need to set the "from" for every transaction call)
web3.eth.defaultAccount = web3.eth.accounts[0]

compiled_contract_path = 'C:/Users/fidha/PycharmProjects/CounterfeitDetection/node_modules/.bin/build/contracts/StructDemo.json'
# Deployed contract address (see `migrate` command output: `contract address`)
deployed_contract_address = '0xD9aCa3a834A97Ac4Ddd01498B33384d42afC0c6B'


@app.route('/',methods=['get','post'])
def Login():
    if request.method=="POST" :
        username=request.form['textfield']
        password=request.form['textfield2']
        db=Db()
        s=db.selectOne("select * from login where username='"+username+"' and password='"+password+"'")
        if s is not None :
            if s['user_type']=='admin' :
                session['lg']='lin'
                return redirect('/Admin_View')
            elif s['user_type']=='customer' :
                session['lg'] = 'lin'
                session['c_id']=s['login_id']
                return redirect('/Customer_View')
            elif s['user_type']=='manufacturer' :
                session['lg'] = 'lin'
                session['m_id'] = s['login_id']
                return redirect('/Manufacturer_View')
        else:
            return "<script>alert('User not found');window.location='/'</script>"
    return render_template("index.html")

@app.route('/Logout')
def Logout():
    session.clear()
    session['lg']=""
    return  redirect('/')


@app.route('/Admin_View')
def Admin_View():
    if session['lg']=="lin" :
        db=Db()
        return render_template("Admin/index.html")
    else :
        return redirect('/')

@app.route('/Approve_or_Reject_Manufacturer')
def Approve_or_Reject_Manufacturer():
    if session['lg'] == "lin":
        db=Db()
        s=db.select("select * from manufacturer, login where manufacturer.manufacturer_id=login.login_id and login.user_type='pending'")
        return render_template("Admin/Approve or Reject Manufacturer.html", data=s)
    else :
        return  redirect('/')

@app.route('/Approve_Manufacturer/<id>/<e1>')
def Approve_Manufacturer(id,e1):
    if session['lg'] == "lin":
        db=Db()
        db.update("update login set user_type='manufacturer' where login_id='"+str(id)+"'")
        from email.mime import image
        import os
        import smtplib
        from email.mime.text import MIMEText
        from flask_mail import Mail

        try:
            gmail = smtplib.SMTP('smtp.gmail.com', 587)

            gmail.ehlo()

            gmail.starttls()

            gmail.login('aishazeba0320@gmail.com', 'aisha@123')

        except Exception as e:
            print("Couldn't setup email!!" + str(e))

        msg = MIMEText("Your Verification was Completed Scuccessfully.")

        msg['Subject'] = 'Verification'

        msg['To'] = e1

        msg['From'] = 'aishazeba0320@gmail.com'

        try:

            gmail.send_message(msg)

        except Exception as e:

            print("COULDN'T SEND EMAIL", str(e))
        return redirect('/Approve_or_Reject_Manufacturer')
    else :
        return redirect('/')

@app.route('/Reject_Manufacturer/<id>/<e1>')
def Reject_Manufacturer(id,e1):
    if session['lg'] == "lin":
        db=Db()
        db.delete("delete from login where login_id='" + str(id) + "'")
        db.delete("delete from manufacturer where manufacturer_id='" + str(id) + "'")
        from email.mime import image
        import os
        import smtplib
        from email.mime.text import MIMEText
        from flask_mail import Mail

        try:
            gmail = smtplib.SMTP('smtp.gmail.com', 587)

            gmail.ehlo()

            gmail.starttls()

            gmail.login('aishazeba0320@gmail.com', 'aisha@123')

        except Exception as e:
            print("Couldn't setup email!!" + str(e))

        msg = MIMEText("Your Verification was declined.")

        msg['Subject'] = 'Verification'

        msg['To'] = e1

        msg['From'] = 'aishazeba0320@gmail.com'

        try:

            gmail.send_message(msg)

        except Exception as e:

            print("COULDN'T SEND EMAIL", str(e))
        return redirect('/Approve_or_Reject_Manufacturer')
    else :
        return redirect('/')

@app.route('/View_Customer')
def View_Customer():
    if session['lg'] == "lin":
        db=Db()
        s = db.select("select * from customer")
        return render_template("Admin/View Customer.html", data=s)
    else :
        return redirect('/')

@app.route('/View_Feedback1')
def View_Feedback1():
    if session['lg'] == "lin":
        db=Db()
        s = db.select("select * from feedback, customer, manufacturer where feedback.manufacturer_id=manufacturer.manufacturer_id and feedback.customer_id=customer.customer_id")
        return render_template("Admin/View Feedback.html",data=s)
    else :
        return redirect('/')

@app.route('/Customer_View')
def Customer_View():
    if session['lg'] == "lin":
        db=Db()
        return render_template("Customer/index.html")
    else :
        return redirect('/')

@app.route('/Customer_Registration',methods=['get','post'])
def Customer_Registration():
    # if session['lg'] == "lin":
        if request.method == "POST":
            name = request.form['textfield']
            email = request.form['textfield2']
            phoneno=request.form['textfield3']
            place=request.form['textfield4']
            photo = request.files['fileField']
            date=datetime.datetime.now().strftime('%y%m%d-%H%M%S')
            photo.save(r"C:\Users\fidha\PycharmProjects\CounterfeitDetection\static\\"+date+'.jpg')
            photo1="/static/"+date+'.jpg'
            password=request.form['textfield5']
            db=Db()
            s=db.insert("insert into login values(null,'"+email+"', '"+password+"', 'customer')")
            db.insert("insert into customer values('"+str(s)+"', '"+name+"', '"+email+"', '"+phoneno+"', '"+place+"', '"+photo1+"')")
            return "<script>alert('Registered successfully');window.location='/'</script>"
        return render_template("CustomerReg.html")
    # else :
    #     return redirect('/')

@app.route('/View_Product2',methods=['get','post'])
def View_Product2():

    if session['lg'] == "lin":
        if request.method=='POST':
            data = []
            with open(compiled_contract_path) as file:
                contract_json = json.load(file)  # load contract info as JSON
                contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
            contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
            blocknumber = web3.eth.get_block_number()
            print(blocknumber)
            for i in range(blocknumber, 4, -1):
                a = web3.eth.get_transaction_by_block(i, 0)
                decoded_input = contract.decode_function_input(a['input'])
                res = {}
                res['productname'] = decoded_input[1]['p']
                res['location'] = decoded_input[1]['l']
                res['timestamp'] = decoded_input[1]['t']
                res['price'] = decoded_input[1]['price']
                res['ins'] = decoded_input[1]['ins']
                res['photo'] = decoded_input[1]['photo']
                res['mname']=decoded_input[1]['m']
                # db = Db()
                # q = db.selectOne(
                #     "select * from `manufacturer` WHERE `manufacturer_id`='" + str(decoded_input[1]['mid']) + "' and m_name like '%"+request.form['n']+"%'")
                # if q is not None:
                #     res['m_name'] = q['m_name']
                data.append(res)
            return render_template("Customer/View Product.html", data=data)

        data = []
        with open(compiled_contract_path) as file:
            contract_json = json.load(file)  # load contract info as JSON
            contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
        contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
        blocknumber = web3.eth.get_block_number()
        print(blocknumber)
        for i in range(blocknumber, 4, -1):
            a = web3.eth.get_transaction_by_block(i, 0)
            decoded_input = contract.decode_function_input(a['input'])
            res = {}
            res['productname'] = decoded_input[1]['p']
            res['location'] = decoded_input[1]['l']
            res['timestamp'] = decoded_input[1]['t']
            res['price'] = decoded_input[1]['price']
            res['ins'] = decoded_input[1]['ins']
            res['photo'] = decoded_input[1]['photo']
            res['mname'] = decoded_input[1]['m']

            # if str(decoded_input[1]['mid']) == str(session['m_id']):
            data.append(res)
        return render_template("Customer/View Product.html",data=data)
    else :
        return redirect('/')

@app.route('/Send_Feedback',methods=['get','post'])
def Send_Feedback():
    if session['lg'] == "lin":
        db = Db()
        if request.method=="POST" :
            feedback=request.form['textarea']
            manufacturer=request.form['select']
            db.insert("insert into feedback values(NULL , '" + feedback + "', '"+str(session['c_id'])+"', '"+manufacturer+"', curdate())")
            return "<script>alert('Added successfully');window.location='/Send_Feedback'</script>"
        else :
            s=db.select("select * from manufacturer")
            return render_template("Customer/Send Feedback.html",data=s)
    else :
        return redirect('/')

@app.route('/View_Product1')
def View_Product1():
    if session['lg'] == "lin":
        data = []
        with open(compiled_contract_path) as file:
            contract_json = json.load(file)  # load contract info as JSON
            contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
        contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
        blocknumber = web3.eth.get_block_number()
        print(blocknumber)
        for i in range(blocknumber, 4, -1):
            a = web3.eth.get_transaction_by_block(i, 0)

            print(a)
            decoded_input = contract.decode_function_input(a['input'])
            res = {}
            res['productname'] = decoded_input[1]['p']
            res['location'] = decoded_input[1]['l']
            res['timestamp'] = decoded_input[1]['t']
            res['price'] = decoded_input[1]['price']
            res['ins'] = decoded_input[1]['ins']
            res['photo'] = decoded_input[1]['photo']
            res['mid'] = decoded_input[1]['mid']
            if str(decoded_input[1]['mid']) == str(session['m_id']):
                data.append(res)
        return render_template("Manufacturer/View Product.html",data=data)
    else :
        return redirect('/')

@app.route('/Manufacturer_View')
def Manufacturer_View():
    if session['lg'] == "lin":
        db=Db()
        return render_template("Manufacturer/index.html")
    else :
        return redirect('/')

@app.route('/Manufacturer_Registration',methods=['get','post'])
def Manufacturer_Registration():
    # if session['lg'] == "lin":
        if request.method == "POST":
            name = request.form['textfield']
            email = request.form['textfield2']
            phoneno=request.form['textfield3']
            place=request.form['textfield4']
            photo = request.files['fileField']
            date = datetime.datetime.now().strftime('%y%m%d-%H%M%S')
            photo.save(r"C:\Users\fidha\PycharmProjects\CounterfeitDetection\static\\" + date + '.jpg')
            photo1 = "/static/" + date + '.jpg'
            password = request.form['textfield5']
            db = Db()
            s = db.insert("insert into login values(null,'" + email + "', '" + password + "', 'pending')")
            db.insert("insert into manufacturer values('" + str(s) + "', '" + name + "', '" + email + "', '" + phoneno + "', '" + place + "', '" + photo1 + "')")
            return "<script>alert('Registered successfully !!! Wait for further updation');window.location='/'</script>"
        return render_template("ManufacturerReg.html")
    # else :
    #     return redirect('/')

@app.route('/Product_Management',methods=['get','post'])
def Product_Management():
    if session['lg'] == "lin":
        if request.method == "POST":
            productname = request.form['textfield']
            location = request.form['textfield2']
            ingredients=request.form['textfield4']
            price=request.form['textfield3']
            timestamp = request.form['textfield5']
            photo = request.files['fileField']
            import datetime,qrcode
            date = datetime.datetime.now().strftime('%y%m%d-%H%M%S')
            photo.save(r"C:\Users\fidha\PycharmProjects\CounterfeitDetection\static\products\\" + date + '.jpg')
            photo1 = "/static/products/" + date + '.jpg'
            db = Db()
            q = db.selectOne(
                "select * from `manufacturer` WHERE `manufacturer_id`='" +str(session['m_id'])+ "'")
            if q is not None:
                mname= q['m_name']
            with open(compiled_contract_path) as file:
                contract_json = json.load(file)  # load contract info as JSON
                contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions

            contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
            blocknumber = web3.eth.get_block_number()

            message2 = contract.functions.addProduct(blocknumber + 1, productname, mname, location, timestamp, price, ingredients, photo1, (session['m_id'])).transact()

            # Create qr code instance
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=3,
                border=4,
            )
            # Add data
            qr.add_data(blocknumber + 1)
            qr.make(fit=True)
            import datetime
            img = qr.make_image()
            img.save(r"C:\Users\fidha\PycharmProjects\CounterfeitDetection\static\\" + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + "image.jpg")
            return "<script>alert('Added successfully');window.location='/Product_Management'</script>"
            # db.insert("insert into product values('', '" + productname + "', '" + location + "', '" + ingredients + "', '" + usagedetails + "', '"+timestamp+"', '" + photo1 + "', '"+str(session['m_id'])+"')")
        return render_template("Manufacturer/Product Management.html")
    else :
        return redirect('/')

@app.route('/View_Feedback2')
def View_Feedback2():
    if session['lg'] == "lin":
        db=Db()
        s = db.select("select * from feedback, customer, manufacturer where feedback.manufacturer_id=manufacturer.manufacturer_id and feedback.customer_id=customer.customer_id and manufacturer.manufacturer_id='"+str(session['m_id'])+"'")
        return render_template("Manufacturer/View Feedback.html", data=s)
    else :
        return redirect('/')

@app.route('/detection',methods=['post'])
def detection():
    bid=request.form['srno']
    with open(compiled_contract_path) as file:
        contract_json = json.load(file)  # load contract info as JSON
        contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
    contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
    blocknumber = web3.eth.get_block_number()
    print(blocknumber)
    for i in range(blocknumber, 4, -1):
        a = web3.eth.get_transaction_by_block(i, 0)
        decoded_input = contract.decode_function_input(a['input'])
        if str(decoded_input[1]['bid'])==bid:
            return jsonify(status="ok",p=decoded_input[1]['p'], m=decoded_input[1]['m'], l=decoded_input[1]['l'],t=decoded_input[1]['t'], price=decoded_input[1]['price'], i=decoded_input[1]['ins'], photo=decoded_input[1]['photo'])
        else:
            return jsonify(status="none")


if __name__ == '__main__':
    app.run(host="0.0.0.0")
    # app.run()
