package com.example.counterfeitdetection;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Detect_Counterfeit extends AppCompatActivity {
ImageView i;
TextView t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13;
String content,url;
SharedPreferences sh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detect__counterfeit);
        i=findViewById(R.id.imageView2);
        t1=findViewById(R.id.textView8);
        t2=findViewById(R.id.textView11);
        t3=findViewById(R.id.textView12);
        t4=findViewById(R.id.textView15);
        t5=findViewById(R.id.textView16);
        t12=findViewById(R.id.textView21);
        content=Scan_qr.contents;
        Toast.makeText(this, ""+content, Toast.LENGTH_SHORT).show();

        t6=findViewById(R.id.textView10);
        t7=findViewById(R.id.textView9);
        t8=findViewById(R.id.textView13);
        t9=findViewById(R.id.textView14);
        t10=findViewById(R.id.textView17);
        t13=findViewById(R.id.textView22);
        t11=findViewById(R.id.textView18);
        t11.setVisibility(View.INVISIBLE);
        url=" http://192.168.1.5:5000/"+"detection";
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                // Display the response string.

                Toast.makeText(getApplicationContext(), "QR Code Verified" , Toast.LENGTH_SHORT).show();
                try {

                    JSONObject jsonObj1 = new JSONObject(response);
                    if (jsonObj1.getString("status").equalsIgnoreCase("ok")) {
//                        JSONObject jsonObj=jsonObj1.getJSONObject("result");

                        t1.setText(jsonObj1.getString("p"));
                        t2.setText(jsonObj1.getString("l"));
                        t3.setText(jsonObj1.getString("t"));
                        t4.setText(jsonObj1.getString("price"));
                        t5.setText(jsonObj1.getString("i"));
                        t13.setText(jsonObj1.getString("m"));
                        String images= jsonObj1.getString("photo");
                        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        String ip=sh.getString("ip","");
                        String url=" http://192.168.1.5:5000/"+images;
                        Picasso.with(getApplicationContext()).load(url). into(i);//circle


                    } else {
                        t1.setVisibility(View.INVISIBLE);
                        t2.setVisibility(View.INVISIBLE);
                        t3.setVisibility(View.INVISIBLE);
                        t4.setVisibility(View.INVISIBLE);
                        t5.setVisibility(View.INVISIBLE);
                        t6.setVisibility(View.INVISIBLE);
                        t7.setVisibility(View.INVISIBLE);
                        t8.setVisibility(View.INVISIBLE);
                        t9.setVisibility(View.INVISIBLE);
                        t10.setVisibility(View.INVISIBLE);
                        t12.setVisibility(View.INVISIBLE);
                        t13.setVisibility(View.INVISIBLE);
                        i.setVisibility(View.INVISIBLE);
//                        t12.setVisibility(View.INVISIBLE);
                        t11.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    Log.d("=========", e.toString());
                    Toast.makeText(getApplicationContext(), ""+e, Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {

            //                value Passing android to python
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();
                params.put("srno", content);//passing to python
                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS=120000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ij = new Intent(getApplicationContext(),Scan_qr.class);
        startActivity(ij);
    }
}
